##
# Auteur JOLLIET Corentin
# Version 0.1 : Date : Wed Dec 19 15:38:33 CET 2018
#
require 'gtk3'

class Builder < Gtk::Builder
	@@mode = 1
	@@taille = 1
	@@difficulte = 1

	def initialize 
	    super()
	    self.add_from_file(__FILE__.sub(".rb",".glade"))
		# Creation d'une variable d'instance par composant identifié dans glade
		puts "Création des variables d'instances"
		self.objects.each() { |p| 	
				unless p.builder_name.start_with?("___object") 
					puts "\tCreation de la variable d'instance @#{p.builder_name}"
					instance_variable_set("@#{p.builder_name}".intern, self[p.builder_name]) 
				end
		}
		@window1.show_all
		@window1.signal_connect('destroy') { puts "Tchao !"; Gtk.main_quit }
		# On connecte les signaux aux méthodes (qui doivent exister)
		@quitter.signal_connect('clicked') { puts "Tchao !"; Gtk.main_quit }
		@play.signal_connect('clicked'){ puts "*Musique d'annonce*\nLa fonctionnalité que vous souhaitez utiliser est actuellement indisponible";}

		@modeNormal.signal_connect('toggled') {
			
			if (@@mode != 1) && @modeAventure.active?
				@modeAventure.active = false;
				@modeNormal.active = true;
				@@mode = 1;
			end
			
			if @modeNormal.active?
				puts "Mode : Normal - #{@@mode}";
			end
		}
		
		@modeAventure.signal_connect('toggled') {
			
			if (@@mode != 2) && @modeNormal.active?
				@modeNormal.active = false;
				@modeAventure.active = true;
				@@mode = 2;
			end
			
			if @modeAventure.active?
				puts "Mode : Aventure - #{@@mode}";
			end
		}

		@taille77.signal_connect('toggled') {
			
			if @@taille != 1
				@taille1010.active = false;
				@taille1515.active = false;
				@taille77.active = true;
				@@taille = 1;
			end

			if @taille77.active?
				puts "Taille grille : 7*7 - #{@@taille}";
			end
		}

		@taille1010.signal_connect('toggled') {
						
			if @@taille != 2
				@taille77.active = false;
				@taille1515.active = false;
				@taille1010.active = true;
				@@taille = 2;
			end
			
			if @taille1010.active?
				puts "Taille grille : 10*10 - #{@@taille}";
			end
		}

		@taille1515.signal_connect('toggled') {
			
			if @@taille != 3
				@taille77.active = false;
				@taille1010.active = false;
				@taille1515.active = true;
				@@taille = 3;
			end

			if @taille1515.active?
				puts "Taille grille : 15*15 - #{@@taille}";
			end
		}

		@diffFacile.signal_connect('toggled'){
		
			if @@difficulte != 1
				@diffNormal.active = false;
				@diffDifficile.active = false;
				@diffFacile.active = true;
				@@difficulte = 1;
			end

			if @diffFacile.active?
				puts "Difficultée : Facile - #{@@difficulte}";
			end
		}

		@diffNormal.signal_connect('toggled'){
			if @@difficulte != 2
				@diffDifficile.active = false;
				@diffFacile.active = false;
				@diffNormal.active = true;
				@@difficulte = 2;
			end

			if @diffNormal.active?
				puts "Difficultée : Normale - #{@@difficulte}";
			end
		}

		@diffDifficile.signal_connect('toggled'){
			if @@difficulte != 3
				@diffFacile.active = false;
				@diffNormal.active = false;
				@diffDifficile.active = true;
				@@difficulte = 3;
			end

			if @diffDifficile.active?
				puts "Difficultée : Difficile - #{@@difficulte}";
			end
		}
		
		puts "\nConnexion des signaux"
		self.connect_signals { |handler| 
				puts "\tConnection du signal #{handler}"
				begin
					method(handler) 
				rescue	
					puts "\t\t[Attention] Vous devez definir la methode #{handler} :\n\t\t\tdef #{handler}\n\t\t\t\t....\n\t\t\tend\n"
					self.class.send( :define_method, handler.intern) {
						puts "La methode #{handler} n'est pas encore définie.. Arrêt"
						Gtk.main_quit
					}
					retry
				end
		}	
	end

	# A partir d'ici on écrit le code

	
	
end

# On lance l'application
builder = Builder.new()
Gtk.main

