require 'gtk3'

class Menu
    
    @builder
    @builderJeu
    @window
    @btnQuitter
    @btnJouer

     def initialize()
        @builder = Gtk::Builder.new
     end

     def afficheDemarrage()
		if(@window != nil) then
			@window.destroy()
		end
        @builder.add_from_file("../glade/menu.glade")
        
        # GET_OBJECT
        @window = @builder.get_object("windowMenu")
        @btnQuitter = @builder.get_object("btnQuitter")
        @btnJouer = @builder.get_object("btnJouer")

        # SIGNAUX
        @window.signal_connect('destroy') { |_widget| Gtk.main_quit }
        @btnQuitter.signal_connect('clicked') { puts "Tchao !"; Gtk.main_quit }
        @btnJouer.signal_connect('clicked') { |_widget| changerFenetre() }

		@window.show()
		Gtk.main()
    end
    
    def changerFenetre()
        @window.destroy()
        @builderJeu = Gtk::Builder.new
        @builderJeu.add_from_file("../glade/jeu.glade")
        @window = @builderJeu.get_object("windowJeu")
        @window.show()
        Gtk.main()  
    end
end

menu = Menu.new()
menu.afficheDemarrage()